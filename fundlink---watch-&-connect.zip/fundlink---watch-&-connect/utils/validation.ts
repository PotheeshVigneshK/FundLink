// Input validation and sanitization utilities

export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validatePhone = (phone: string): boolean => {
  // Simple phone validation - can be enhanced based on requirements
  const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
  return phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''));
};

export const sanitizeString = (str: string): string => {
  if (typeof str !== 'string') return '';
  
  // Remove potentially dangerous characters but preserve common punctuation
  return str
    .trim()
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
    .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '') // Remove iframe tags
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/vbscript:/gi, '') // Remove vbscript: protocol
    .replace(/on\w+\s*=/gi, '') // Remove event handlers
    .substring(0, 1000); // Limit length to prevent overflow
};

export const validatePassword = (password: string): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long');
  }
  
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }
  
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }
  
  if (!/\d/.test(password)) {
    errors.push('Password must contain at least one number');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

export const validateOTP = (otp: string): boolean => {
  return /^\d{6}$/.test(otp); // 6-digit OTP validation
};

export const validateProjectName = (name: string): { isValid: boolean; error?: string } => {
  if (!name || name.trim().length < 2) {
    return { isValid: false, error: 'Project name must be at least 2 characters long' };
  }
  
  if (name.length > 100) {
    return { isValid: false, error: 'Project name must be less than 100 characters' };
  }
  
  // Check for potentially dangerous characters
  if (/[<>'"&]/.test(name)) {
    return { isValid: false, error: 'Project name contains invalid characters' };
  }
  
  return { isValid: true };
};

export const validateIndustry = (industry: string): { isValid: boolean; error?: string } => {
  if (!industry || industry.trim().length < 2) {
    return { isValid: false, error: 'Industry must be at least 2 characters long' };
  }
  
  if (industry.length > 100) {
    return { isValid: false, error: 'Industry must be less than 100 characters' };
  }
  
  // Check for potentially dangerous characters
  if (/[<>'"&]/.test(industry)) {
    return { isValid: false, error: 'Industry contains invalid characters' };
  }
  
  return { isValid: true };
};

export const validateGeography = (geography: string): { isValid: boolean; error?: string } => {
  if (!geography || geography.trim().length < 2) {
    return { isValid: false, error: 'Geography must be at least 2 characters long' };
  }
  
  if (geography.length > 100) {
    return { isValid: false, error: 'Geography must be less than 100 characters' };
  }
  
  // Check for potentially dangerous characters
  if (/[<>'"&]/.test(geography)) {
    return { isValid: false, error: 'Geography contains invalid characters' };
  }
  
  return { isValid: true };
};
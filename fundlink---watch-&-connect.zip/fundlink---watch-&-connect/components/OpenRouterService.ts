import axios from 'axios';

interface GenerateContentRequest {
  contents: Array<{
    role: string;
    parts: Array<{
      text: string;
    }>;
  }>;
  config?: {
    responseMimeType?: string;
  };
  model?: string;
}

interface GenerateContentResponse {
  text: () => string;
}

export class OpenRouterService {
  private apiKey: string;
  private baseUrl: string = 'https://openrouter.ai/api/v1';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async generateContent(request: GenerateContentRequest): Promise<GenerateContentResponse> {
    try {
      // Validate API key exists
      if (!this.apiKey) {
        throw new Error('API key is required but not provided');
      }
      
      const messages = request.contents.map(content => {
        return {
          role: content.role,
          content: content.parts.map(part => part.text).join(' ')
        };
      });

      const requestBody = {
        model: request.model || "mistralai/devstral-2512:free",
        messages: messages,
        ...(request.config?.responseMimeType && { 
          response_format: { type: request.config.responseMimeType === "application/json" ? "json_object" : "text" }
        })
      };

      const response = await axios.post(`${this.baseUrl}/chat/completions`, requestBody, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'http://localhost:3000', // Replace with your site URL
          'X-Title': 'FundLink App' // Replace with your site name
        },
        timeout: 30000 // 30 second timeout
      });

      // Check if response is valid
      if (!response.data || !response.data.choices || response.data.choices.length === 0) {
        throw new Error('Invalid response from AI service');
      }

      // Return a response object that mimics the Google GenAI response format
      return {
        text: () => {
          const content = response.data.choices[0]?.message?.content || '';
          return content;
        }
      };
    } catch (error: any) {
      console.error('OpenRouter API Error:', error);
      
      // Handle different types of errors
      if (error.response) {
        // Server responded with error status
        const status = error.response.status;
        if (status === 401) {
          throw new Error('Invalid API key. Please check your credentials.');
        } else if (status === 429) {
          throw new Error('Rate limit exceeded. Please try again later.');
        } else if (status >= 500) {
          throw new Error('AI service is temporarily unavailable. Please try again later.');
        } else {
          throw new Error(`AI service error (${status}): ${error.response.data?.error?.message || 'Unknown error'}`);
        }
      } else if (error.request) {
        // Request was made but no response received
        throw new Error('Network error: Unable to connect to AI service. Please check your connection.');
      } else {
        // Something else happened
        throw new Error(error.message || 'An error occurred while communicating with the AI service.');
      }
    }
  }
}
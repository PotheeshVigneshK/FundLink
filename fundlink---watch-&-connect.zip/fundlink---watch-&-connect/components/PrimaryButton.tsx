
import React from 'react';

interface PrimaryButtonProps {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  loading?: boolean;
}

export const PrimaryButton: React.FC<PrimaryButtonProps> = ({ 
  label, 
  onClick, 
  disabled = false,
  loading = false
}) => {
  return (
    <div className="absolute bottom-10 left-0 right-0 px-8">
      <div className={`rounded-[2rem] p-1 transition-all duration-300 ${!disabled && !loading ? 'bg-indigo-600/10 shadow-[0_0_20px_rgba(79,70,229,0.3)]' : ''}`}>
        <button
          onClick={onClick}
          disabled={disabled || loading}
          className={`w-full py-4.5 rounded-[1.8rem] font-black text-sm uppercase tracking-[0.2em] transition-all duration-200 transform active:scale-[0.98] h-14 ${
            disabled 
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200' 
              : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-xl'
          }`}
        >
          {loading ? (
            <div className="flex items-center justify-center space-x-2">
              <div className="w-1.5 h-1.5 bg-white rounded-full animate-bounce" />
              <div className="w-1.5 h-1.5 bg-white rounded-full animate-bounce [animation-delay:0.2s]" />
              <div className="w-1.5 h-1.5 bg-white rounded-full animate-bounce [animation-delay:0.4s]" />
            </div>
          ) : label}
        </button>
      </div>
    </div>
  );
};

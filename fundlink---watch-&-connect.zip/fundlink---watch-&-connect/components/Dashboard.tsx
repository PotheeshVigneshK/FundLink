
import React, { useEffect, useState, useMemo } from 'react';
import { UserRole, Connection } from '../types';
import { OpenRouterService } from './OpenRouterService';
import { DeepDiveOverlay } from './DeepDiveOverlay';
import { SkeletonList, SkeletonCard, Skeleton } from './Skeleton';

interface DashboardProps {
  role: UserRole;
  profile: any;
  onConnect: (connection: Connection) => void;
}

interface AIInsight {
  title: string;
  value: string | number;
  label: string;
  desc: string;
  trend: 'UP' | 'DOWN' | 'STABLE';
  icon: string;
}

export const Dashboard: React.FC<DashboardProps> = ({ role, profile, onConnect }) => {
  const [activeTab, setActiveTab] = useState<'discovery' | 'connections'>('discovery');
  const [matches, setMatches] = useState<any[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTarget, setSelectedTarget] = useState<any | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedInsight, setExpandedInsight] = useState<number | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);

  // Calculate number of pending connection requests
  const pendingRequests = connections.filter(conn => conn.status === 'PENDING').length;

  useEffect(() => {
    const runDiscoveryEngine = async () => {
      setLoading(true);
      const ai = new OpenRouterService(process.env.API_KEY || '');
      
      const basePool: any[] = role === UserRole.FOUNDER 
        ? [
            { id: 1, name: "Nexus Venture Partners", type: "VC Fund", sectors: ["FinTech", "AI"], ticket: "$1M - $5M", geography: "India", matchScore: 98 },
            { id: 2, name: "Angel Syndicate Alpha", type: "Angel", sectors: ["SaaS", "DeepTech"], ticket: "$500k+", geography: "India", matchScore: 92 },
            { id: 3, name: "Blume Ventures", type: "VC Fund", sectors: ["SaaS", "Consumer"], ticket: "$100k - $1M", geography: "India", matchScore: 88 }
          ]
        : [
            { id: 1, title: "FinFlow Analytics", domain: "FinTech", stage: "MVP", geography: "India", matchScore: 96, summary: "AI-driven cashflow forecasting for SMEs in emerging markets." },
            { id: 2, title: "EcoCharge", domain: "CleanTech", stage: "Live", geography: "India", matchScore: 91, summary: "Smart EV charging infrastructure for urban residential complexes." }
          ];

      try {
        const prompt = `Act as FundLink Principal Intelligence. Given user profile: ${JSON.stringify(profile)}. 
          Analyze these matches and provide a 10-word synergy reason for the top ones.
          Entities: ${JSON.stringify(basePool.map(e => ({ id: e.id, name: e.name || e.title })))}
          Return JSON ONLY: { "insights": [ { "id": number, "reason": string } ] }`;

        const response = await ai.generateContent({
          contents: [{
            role: 'user',
            parts: [{ text: prompt }]
          }],
          config: { responseMimeType: "application/json" },
          model: 'mistralai/devstral-2512:free'
        });
        
        const data = JSON.parse(response.text() || '{"insights": []}');
        const insightMap = new Map(data.insights.map((item: any) => [item.id, item.reason]));
        
        setMatches(basePool.map(item => ({
          ...item,
          aiInsight: insightMap.get(item.id) || "Strong alignment with your core sector thesis."
        })).sort((a, b) => b.matchScore - a.matchScore));

        const neuralInsights: AIInsight[] = role === UserRole.FOUNDER ? [
          { title: "Profile Integrity", value: "94%", label: "Verified", desc: "Institutional data points are 94% complete.", trend: "UP", icon: "💎" },
          { title: "Pitch Readiness", value: profile?.readinessScore || 85, label: "Top Tier", desc: "Metrics are in the top 5% of your sector.", trend: "STABLE", icon: "🎯" },
          { title: "Ecosystem Signal", value: "8.2", label: "Strong", desc: "VC search queries for your category are up 12%.", trend: "UP", icon: "⚡" }
        ] : [
          { title: "Portfolio Synergy", value: "88%", label: "Optimal", desc: "88% of current deal-flow matches your core thesis.", trend: "UP", icon: "🔗" },
          { title: "Deal Velocity", value: "12", label: "Signals/Wk", desc: "Matching throughput has increased by 40%.", trend: "UP", icon: "🚀" },
          { title: "Market Heatmap", value: "High", label: "Hot Sectors", desc: "AI & SaaS showing higher capital absorption.", trend: "STABLE", icon: "🔥" }
        ];
        setInsights(neuralInsights);

      } catch (e) {
        setMatches(basePool);
      }
      setLoading(false);
    };

    runDiscoveryEngine();
  }, [role, profile]);

  const handleRequestConnection = (target: any) => {
    const newConn: Connection = {
      id: Math.random().toString(36).substr(2, 9),
      targetId: target.id.toString(),
      targetName: role === UserRole.FOUNDER ? target.name : "Founder of " + target.title,
      projectName: role === UserRole.FOUNDER ? profile?.projectName || "My Startup" : target.title,
      targetRole: role === UserRole.FOUNDER ? UserRole.INVESTOR : UserRole.FOUNDER,
      status: 'PENDING'
    };
    
    setConnections(prev => [...prev, newConn]);
    setSelectedTarget(null);
    setActiveTab('connections');
    
    // In a real app, this would send a notification to the other party
    // For now, we just add the connection with PENDING status
  };

  // Function to accept a connection request
  const handleAcceptConnection = (connId: string) => {
    setConnections(prev => 
      prev.map(conn => 
        conn.id === connId ? { ...conn, status: 'ACCEPTED', lastMessage: "Connection Accepted. Secure Workspace Active." } : conn
      )
    );
  };
  
  // Function to reject a connection request
  const handleRejectConnection = (connId: string) => {
    setConnections(prev => 
      prev.filter(conn => conn.id !== connId) // Remove the connection request
    );
  };
  
  const filteredMatches = useMemo(() => {
    return matches.filter(m => {
      const name = role === UserRole.FOUNDER ? m.name : m.title;
      return name.toLowerCase().includes(searchQuery.toLowerCase());
    });
  }, [matches, searchQuery, role]);

  return (
    <div className="flex flex-col h-screen w-full bg-slate-50 overflow-hidden">
      <header className="px-6 py-5 bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="flex flex-col space-y-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center font-bold text-white shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h1 className="font-black text-slate-900 tracking-tight">FundLink Vault</h1>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="p-2 rounded-xl hover:bg-slate-100 transition-all relative"
                >
                  <svg className="h-6 w-6 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H6" />
                  </svg>
                  {pendingRequests > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[8px] font-black rounded-full h-5 w-5 flex items-center justify-center">
                      {pendingRequests}
                    </span>
                  )}
                </button>
                
                {/* Notification Panel */}
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 z-50">
                    <div className="p-4 border-b border-slate-100">
                      <h3 className="font-black text-slate-900">Notifications</h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {pendingRequests > 0 ? (
                        connections
                          .filter(conn => conn.status === 'PENDING')
                          .map(conn => (
                            <div key={conn.id} className="p-4 border-b border-slate-100 hover:bg-slate-50">
                              <div className="flex justify-between items-start">
                                <div>
                                  <p className="font-bold text-slate-900">Connection Request</p>
                                  <p className="text-sm text-slate-600 mt-1">
                                    {conn.targetName} wants to connect regarding {conn.projectName}
                                  </p>
                                  <p className="text-xs text-slate-400 mt-2">Just now</p>
                                </div>
                                <div className="flex gap-2">
                                  <button
                                    onClick={() => {
                                      handleAcceptConnection(conn.id);
                                      if (connections.filter(c => c.status === 'PENDING').length <= 1) {
                                        setShowNotifications(false);
                                      }
                                    }}
                                    className="px-3 py-1 bg-green-600 text-white text-xs font-black rounded-lg"
                                  >
                                    Accept
                                  </button>
                                  <button
                                    onClick={() => {
                                      handleRejectConnection(conn.id);
                                      if (connections.filter(c => c.status === 'PENDING').length <= 1) {
                                        setShowNotifications(false);
                                      }
                                    }}
                                    className="px-3 py-1 bg-red-600 text-white text-xs font-black rounded-lg"
                                  >
                                    Reject
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))
                      ) : (
                        <div className="p-8 text-center">
                          <p className="text-slate-400">No new notifications</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
              
              <div className="bg-slate-100 p-1 rounded-xl flex gap-1">
                <button 
                  onClick={() => setActiveTab('discovery')}
                  className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'discovery' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-400'}`}
                >
                  Discovery
                </button>
                <button 
                  onClick={() => setActiveTab('connections')}
                  className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all relative ${activeTab === 'connections' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-400'}`}
                >
                  Connections
                  {connections.some(c => c.status === 'ACCEPTED') && <span className="absolute top-1 right-1 w-2 h-2 bg-green-500 rounded-full border-2 border-white" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-6 py-8 pb-32">
        {activeTab === 'discovery' ? (
          <div className="animate-in">
            {/* Insights Dashboard */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
              {insights.map((insight, i) => (
                <div 
                  key={i}
                  onClick={() => setExpandedInsight(expandedInsight === i ? null : i)}
                  className={`bg-gradient-to-br from-white to-slate-50 rounded-[2rem] border transition-all cursor-pointer shadow-sm hover:shadow-md ${expandedInsight === i ? 'p-8 border-indigo-300 ring-4 ring-indigo-100' : 'p-6 border-slate-200'}`}
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-indigo-100 to-white rounded-xl flex items-center justify-center text-lg shadow-inner">
                      {insight.icon}
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">{insight.trend}</span>
                      <span className="text-[10px] font-black text-green-500">▲</span>
                    </div>
                  </div>
                  <h4 className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-2">{insight.title}</h4>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-slate-900 tracking-tighter">{insight.value}</span>
                    <span className="text-xs font-medium text-slate-500">{insight.label}</span>
                  </div>
                  {expandedInsight === i && <p className="mt-4 text-xs font-medium text-slate-600 italic animate-in border-t border-slate-100 pt-3">"{insight.desc}"</p>}
                </div>
              ))}
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-black text-slate-900 tracking-tighter">Matches Found</h2>
              <input 
                type="text" 
                placeholder="Search institutional signals..."
                className="w-full mt-4 p-4 bg-white border border-slate-100 rounded-2xl outline-none focus:border-indigo-600 transition-all shadow-sm"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="space-y-6">
              {loading ? 
                <SkeletonList count={3} /> 
                : 
                filteredMatches.map(item => (
                  <div key={item.id} onClick={() => setSelectedTarget(item)} className="bg-gradient-to-br from-white to-slate-25 p-6 rounded-[2.5rem] border border-slate-200 shadow-sm hover:shadow-lg hover:scale-[1.01] transition-all cursor-pointer group">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="inline-flex items-center px-3 py-1.5 bg-gradient-to-r from-indigo-50 to-indigo-100 text-indigo-700 text-[9px] font-bold uppercase rounded-full mb-3 shadow-sm">
                          <span className="mr-1.5">●</span>
                          {item.matchScore}% Synergy
                        </div>
                        <h3 className="text-xl font-bold text-slate-900 leading-tight group-hover:text-indigo-700 transition-colors mt-1">{role === UserRole.FOUNDER ? item.name : item.title}</h3>
                        <p className="text-[10px] font-medium text-slate-500 uppercase tracking-wider mt-2">{role === UserRole.FOUNDER ? item.type : item.domain} · {item.geography || 'India'}</p>
                        <div className="mt-3 flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-[8px] font-medium text-slate-500 uppercase tracking-wider">Verified Institutional Match</span>
                        </div>
                      </div>
                      <div className="w-12 h-12 bg-gradient-to-br from-slate-100 to-white rounded-full flex items-center justify-center text-slate-400 group-hover:text-indigo-600 transition-colors shadow-inner">
                        <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" /></svg>
                      </div>
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
        ) : (
          <div className="animate-in space-y-6">
            <h2 className="text-2xl font-black text-slate-900 tracking-tighter mb-8">Mutual Connections</h2>
            {connections.length === 0 ? (
              <div className="py-20 text-center bg-white rounded-[3rem] border border-slate-100">
                <div className="text-4xl mb-4">🤝</div>
                <h3 className="text-lg font-black text-slate-800">No active handshakes</h3>
                <p className="text-slate-400 text-sm mt-2">Request connections from Discovery to start discussions.</p>
              </div>
            ) : (
              connections.map(conn => (
                <div key={conn.id} className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-xl">
                      {conn.status === 'ACCEPTED' ? '🔓' : conn.status === 'PENDING' ? '⏳' : '❌'}
                    </div>
                    <div>
                      <h4 className="font-black text-slate-900 tracking-tight">{conn.projectName}</h4>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Discussion with {conn.targetName}</p>
                    </div>
                  </div>
                  {conn.status === 'ACCEPTED' ? (
                    <button 
                      onClick={() => onConnect(conn)}
                      className="px-6 py-3 bg-indigo-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-black transition-all shadow-lg shadow-indigo-100"
                    >
                      Enter Workspace
                    </button>
                  ) : conn.status === 'PENDING' ? (
                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleAcceptConnection(conn.id)}
                        className="px-4 py-2 bg-green-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-green-700 transition-all"
                      >
                        Accept
                      </button>
                      <button 
                        onClick={() => handleRejectConnection(conn.id)}
                        className="px-4 py-2 bg-red-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-red-700 transition-all"
                      >
                        Reject
                      </button>
                    </div>
                  ) : (
                    <span className="px-6 py-3 bg-slate-50 text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest italic">
                      Request {conn.status.toLowerCase()}
                    </span>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </main>

      {selectedTarget && (
        <DeepDiveOverlay 
          role={role} 
          target={selectedTarget} 
          userProfile={profile} 
          onClose={() => setSelectedTarget(null)} 
          onRequestConnection={() => handleRequestConnection(selectedTarget)}
        />
      )}
    </div>
  );
};

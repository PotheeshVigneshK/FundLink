import React from 'react';

interface SkeletonProps {
  className?: string;
  width?: string | number;
  height?: string | number;
  borderRadius?: string;
  animation?: boolean;
}

export const Skeleton: React.FC<SkeletonProps> = ({
  className = '',
  width = '100%',
  height = '1rem',
  borderRadius = '0.5rem',
  animation = true
}) => {
  const style = {
    width: typeof width === 'number' ? `${width}px` : width,
    height: typeof height === 'number' ? `${height}px` : height,
    borderRadius
  };

  const animationClass = animation 
    ? 'animate-pulse bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200' 
    : 'bg-slate-200';

  return (
    <div
      className={`inline-block ${animationClass} ${className}`}
      style={style}
    />
  );
};

interface SkeletonCardProps {
  rows?: number;
  className?: string;
}

export const SkeletonCard: React.FC<SkeletonCardProps> = ({ 
  rows = 3, 
  className = '' 
}) => {
  return (
    <div className={`p-6 rounded-2xl border border-slate-100 bg-white ${className}`}>
      <Skeleton className="mb-4" height="1.5rem" width="60%" />
      <Skeleton className="mb-2" height="1rem" width="80%" />
      <Skeleton className="mb-2" height="1rem" width="70%" />
      {Array.from({ length: rows - 1 }).map((_, i) => (
        <Skeleton key={i} className="mb-2" height="0.875rem" width="90%" />
      ))}
    </div>
  );
};

interface SkeletonListProps {
  count?: number;
  className?: string;
}

export const SkeletonList: React.FC<SkeletonListProps> = ({ 
  count = 5, 
  className = '' 
}) => {
  return (
    <div className={className}>
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="mb-4 last:mb-0">
          <SkeletonCard />
        </div>
      ))}
    </div>
  );
};
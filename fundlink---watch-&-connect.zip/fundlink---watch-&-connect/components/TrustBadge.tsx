
import React, { useState } from 'react';

export const TrustFooter: React.FC = () => (
  <div className="absolute bottom-6 left-0 right-0 text-center px-6">
    <p className="text-[10px] text-slate-400 font-medium tracking-wide uppercase">
      🔒 Privacy-first · No peer visibility · Verified users only
    </p>
  </div>
);

export const WhyTooltip: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative inline-block ml-1">
      <button 
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="text-slate-400 hover:text-indigo-600 transition-colors"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </button>
      
      {isOpen && (
        <div 
          className="absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-3 bg-slate-900 text-white text-[11px] leading-relaxed rounded-xl shadow-xl animate-in"
          onClick={() => setIsOpen(false)}
        >
          <div className="font-bold mb-1">Why we ask this?</div>
          We verify every user to protect privacy and prevent misuse. Your data is never shared without consent.
          <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-l-8 border-l-transparent border-r-8 border-r-transparent border-t-8 border-t-slate-900" />
        </div>
      )}
    </div>
  );
};

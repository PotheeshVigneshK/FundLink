
import React, { useState, useRef, useEffect } from 'react';
import { OpenRouterService } from './OpenRouterService';

export const AIChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'bot', text: string, thinking?: boolean}[]>([
    { role: 'bot', text: 'Principal Intelligence active. How can I assist with your venture strategy?' }
  ]);
  const [input, setInput] = useState('');
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const ai = new OpenRouterService(process.env.API_KEY || '');
      
      const response = await ai.generateContent({
        contents: [{
          role: 'user',
          parts: [{ text: userMsg }]
        }],
        model: isThinkingMode ? 'mistralai/devstral-2512:free' : 'mistralai/devstral-2512:free'
      });

      setMessages(prev => [...prev, { 
        role: 'bot', 
        text: response.text() || 'Unable to process request.',
        thinking: isThinkingMode
      }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'bot', text: 'Connectivity error. Ensure your secure tunnel is active.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-24 right-6 w-16 h-16 bg-indigo-600 rounded-full shadow-2xl flex items-center justify-center z-[60] hover:scale-110 active:scale-90 transition-all border-4 border-white"
      >
        {isOpen ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
          </svg>
        ) : (
          <div className="relative">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
            </svg>
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white animate-pulse" />
          </div>
        )}
      </button>

      {isOpen && (
        <div className="fixed bottom-44 right-6 w-[90vw] max-w-[400px] h-[500px] bg-white rounded-[2.5rem] shadow-2xl z-[60] flex flex-col overflow-hidden border border-slate-100 animate-in">
          <header className="p-6 bg-slate-900 text-white flex justify-between items-center">
            <div>
              <h3 className="font-black text-sm uppercase tracking-widest">Principal AI</h3>
              <p className="text-[10px] text-indigo-300 font-bold">Encrypted Session</p>
            </div>
            <div className="flex items-center gap-2">
               <span className="text-[10px] font-black opacity-60">THINK</span>
               <button 
                onClick={() => setIsThinkingMode(!isThinkingMode)}
                className={`w-10 h-6 rounded-full relative transition-colors ${isThinkingMode ? 'bg-indigo-500' : 'bg-slate-700'}`}
               >
                 <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${isThinkingMode ? 'left-5' : 'left-1'}`} />
               </button>
            </div>
          </header>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-2xl text-xs font-medium ${
                  m.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white text-slate-800 rounded-tl-none border border-slate-200'
                }`}>
                  {m.thinking && m.role === 'bot' && (
                    <div className="flex items-center gap-1 text-[8px] font-black text-indigo-600 uppercase mb-2">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                      </svg>
                      Deep Analysis Complete
                    </div>
                  )}
                  {m.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-white p-4 rounded-2xl border border-slate-200 flex gap-1">
                  <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce" />
                  <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}
          </div>

          <div className="p-4 bg-white border-t border-slate-100 flex gap-2">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Query institutional data..."
              className="flex-1 bg-slate-100 p-4 rounded-xl text-xs outline-none focus:bg-slate-50 transition-all font-medium"
            />
            <button 
              onClick={handleSend}
              className="w-12 h-12 bg-indigo-600 text-white rounded-xl flex items-center justify-center hover:bg-indigo-700 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
        </div>
      )}
    </>
  );
};

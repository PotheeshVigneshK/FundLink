
import React from 'react';
import { UserRole } from '../types';

interface RoleCardProps {
  role: UserRole;
  title: string;
  description: string;
  icon: string;
  isSelected: boolean;
  onSelect: (role: UserRole) => void;
}

export const RoleCard: React.FC<RoleCardProps> = ({ 
  role, 
  title, 
  description, 
  icon, 
  isSelected, 
  onSelect 
}) => {
  const handleClick = () => {
    if ('vibrate' in navigator) {
      navigator.vibrate(10);
    }
    onSelect(role);
  };

  const getIconBackground = () => {
    if (role === UserRole.FOUNDER) return 'bg-gradient-to-br from-indigo-400 to-indigo-600 shadow-indigo-200';
    return 'bg-slate-50 border border-slate-100';
  };

  return (
    <button
      onClick={handleClick}
      className={`w-full p-5 mb-4 rounded-[2rem] border-2 text-left transition-all duration-300 relative group overflow-hidden ${
        isSelected 
          ? 'bg-indigo-50/50 border-indigo-600/80 shadow-[0_8px_30px_rgb(79,70,229,0.1)]' 
          : 'bg-slate-50/50 border-transparent hover:border-slate-200 shadow-sm'
      }`}
    >
      <div className="flex items-center space-x-5 relative z-10">
        <div className={`w-14 h-14 flex items-center justify-center rounded-2xl text-2xl shadow-lg transition-transform duration-300 group-hover:scale-105 ${getIconBackground()}`}>
          {icon}
        </div>
        <div>
          <h3 className={`font-black text-lg tracking-tight ${isSelected ? 'text-indigo-950' : 'text-slate-800'}`}>
            {title}
          </h3>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-0.5">
            {description}
          </p>
        </div>
      </div>
      {isSelected && (
        <div className="absolute top-0 right-0 p-4">
           <div className="w-5 h-5 bg-indigo-600 rounded-full flex items-center justify-center">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" viewBox="0 0 20 20" fill="currentColor">
               <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
             </svg>
           </div>
        </div>
      )}
    </button>
  );
};

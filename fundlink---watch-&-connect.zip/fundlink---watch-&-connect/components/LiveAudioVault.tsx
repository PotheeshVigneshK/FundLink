
import React, { useEffect, useRef, useState } from 'react';
// Note: OpenRouter doesn't support live audio streaming, so we'll keep this component as a simulation

interface LiveAudioVaultProps {
  targetName: string;
  onClose: () => void;
}

export const LiveAudioVault: React.FC<LiveAudioVaultProps> = ({ targetName, onClose }) => {
  const [isActive, setIsActive] = useState(false);
  const [status, setStatus] = useState('Establishing Link...');
  const [volume, setVolume] = useState(0);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef(new Set<AudioBufferSourceNode>());
  const sessionRef = useRef<any>(null);

  const cleanup = () => {
    setIsActive(false);
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    for (const source of sourcesRef.current) {
      source.stop();
    }
    sourcesRef.current.clear();
    if (audioContextRef.current) audioContextRef.current.close();
    if (outputAudioContextRef.current) outputAudioContextRef.current.close();
  };

  useEffect(() => {
    // Simulate audio vault functionality since OpenRouter doesn't support live audio streaming
    const initSession = async () => {
      try {
        // Initialize audio context for volume visualization only
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        
        // Simulate getting user media
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        // Simulate connection
        setIsActive(true);
        setStatus('Secure Neural Link Active');
        
        const source = audioContextRef.current.createMediaStreamSource(stream);
        const scriptProcessor = audioContextRef.current.createScriptProcessor(4096, 1, 1);
        
        scriptProcessor.onaudioprocess = (e) => {
          const inputData = e.inputBuffer.getChannelData(0);
          
          // Visualize volume
          let sum = 0;
          for(let i=0; i<inputData.length; i++) sum += inputData[i] * inputData[i];
          setVolume(Math.sqrt(sum / inputData.length) * 100);
        };
        
        source.connect(scriptProcessor);
        scriptProcessor.connect(audioContextRef.current.destination);
      } catch (err) {
        console.error(err);
        setStatus('Permission Denied');
      }
    };

    initSession();
    return () => cleanup();
  }, []);

  // PCM Encoding Helpers
  const createBlob = (data: Float32Array): { data: string, mimeType: string } => {
    const int16 = new Int16Array(data.length);
    for (let i = 0; i < data.length; i++) int16[i] = data[i] * 32768;
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  };

  const decode = (base64: string) => {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  };

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let ch = 0; ch < numChannels; ch++) {
      const chData = buffer.getChannelData(ch);
      for (let i = 0; i < frameCount; i++) chData[i] = dataInt16[i * numChannels + ch] / 32768.0;
    }
    return buffer;
  };

  return (
    <div className="fixed inset-0 z-[200] bg-slate-950 flex flex-col items-center justify-center p-8 animate-in">
      <div className="absolute top-0 left-0 w-full h-1.5 bg-indigo-600 shadow-[0_0_20px_rgba(79,70,229,0.8)]" />
      
      <div className="max-w-md w-full text-center space-y-12">
        <div className="space-y-2">
          <h2 className="text-4xl font-black text-white tracking-tighter">Audio Vault</h2>
          <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.4em]">{targetName} Discussion</p>
        </div>

        {/* Neural Visualizer */}
        <div className="relative w-64 h-64 mx-auto flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border border-indigo-500/10 scale-125" />
          <div className="absolute inset-0 rounded-full border border-indigo-500/20 scale-110 animate-pulse" />
          
          <div className="flex items-end justify-center gap-1.5 h-32 w-full px-8">
            {[...Array(12)].map((_, i) => (
              <div 
                key={i} 
                className="w-2 bg-indigo-500 rounded-full transition-all duration-75"
                style={{ height: `${10 + Math.random() * (isActive ? volume * 2 : 5)}%`, opacity: 0.3 + (i/12) * 0.7 }}
              />
            ))}
          </div>
          
          <div className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-500 shadow-2xl ${isActive ? 'bg-indigo-600 scale-100 shadow-indigo-500/40' : 'bg-slate-800 scale-90'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-20a3 3 0 013 3v5a3 3 0 01-3 3 3 3 0 01-3-3V5a3 3 0 013-3z" />
            </svg>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-center gap-2">
            <span className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500 animate-pulse' : 'bg-slate-600'}`} />
            <span className="text-[11px] font-black text-white uppercase tracking-widest">{status}</span>
          </div>
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">Signal routed through decentralized secure tunnel</p>
        </div>

        <button 
          onClick={onClose}
          className="w-full py-6 rounded-[2rem] bg-white text-slate-950 font-black text-lg shadow-2xl hover:scale-105 active:scale-95 transition-all"
        >
          Close Audio Vault
        </button>
      </div>
    </div>
  );
};

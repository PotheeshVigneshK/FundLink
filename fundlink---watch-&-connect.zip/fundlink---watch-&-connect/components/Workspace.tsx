
import React, { useState, useRef, useEffect } from 'react';
import { UserRole, Connection } from '../types';
import { ImageTools } from './ImageTools';
import { LiveAudioVault } from './LiveAudioVault';
import { Skeleton } from './Skeleton';

interface Message {
  id: number;
  sender: string;
  text: string;
  time: string;
  type: 'text' | 'image' | string;
  data?: string;
}

interface WorkspaceProps {
  role: UserRole;
  connection: Connection;
  onEnd: (decision: 'ACCEPT' | 'REJECT') => void;
}

export const Workspace: React.FC<WorkspaceProps> = ({ role, connection, onEnd }) => {
  const [messages, setMessages] = useState<Message[]>([
    connection.status === 'ACCEPTED' 
      ? { id: 1, sender: 'System', text: 'Secure Virtual Workspace Established. All interactions are logged for compliance.', time: 'Now', type: 'text' }
      : { id: 1, sender: 'System', text: 'Connection pending acceptance. Workspace will unlock when both parties accept.', time: 'Now', type: 'text' }
  ]);
  const [input, setInput] = useState('');
  const [showClosure, setShowClosure] = useState(false);
  const [terminalDecision, setTerminalDecision] = useState<'ACCEPT' | 'REJECT' | null>(null);
  const [typedConfirmation, setTypedConfirmation] = useState('');
  const [isAudioVaultOpen, setIsAudioVaultOpen] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const sendMessage = (text?: string, type: 'text' | 'image' = 'text', data?: string) => {
    const finalMsg = text || input;
    if (!finalMsg.trim() && !data) return;
    setMessages(prev => [...prev, { 
      id: Date.now(), 
      sender: 'You', 
      text: finalMsg, 
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), 
      type,
      data 
    }]);
    setInput('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        sendMessage('Document shared for view-only audit.', 'image', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Check if the connection is active
  const isConnectionActive = connection.status === 'ACCEPTED';

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950 flex items-center justify-center p-0 sm:p-4">
      {/* Compliance Disclaimer Banner */}
      <div className="absolute top-0 left-0 right-0 bg-slate-900 text-slate-400 py-2 px-6 text-[9px] font-black uppercase tracking-[0.2em] text-center z-[110] border-b border-white/5">
        🔒 VIEW-ONLY MODE ACTIVE: Documents are strictly non-downloadable. Interactions are audited for compliance.
      </div>

      <div className="w-full h-full max-w-5xl bg-white flex flex-col shadow-2xl overflow-hidden sm:rounded-[3rem] relative mt-8">
        
        {/* Workspace Header */}
        <header className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-white/90 backdrop-blur-xl">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-xl shadow-lg">🏛️</div>
            <div>
              <h1 className="text-lg font-black text-slate-900 tracking-tight">{connection.projectName} Viewing Room</h1>
              <p className="text-[9px] font-black text-indigo-600 uppercase tracking-widest">Contributors: You, {connection.targetName}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => setIsAudioVaultOpen(true)} className="p-3 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-100 transition-all">
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
            </button>
            <button 
              onClick={() => setShowClosure(true)} 
              className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-black transition-all shadow-xl"
            >
              End Conversation
            </button>
          </div>
        </header>

        {/* Messaging Area */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-6 bg-slate-50/50 hide-scrollbar" onContextMenu={e => e.preventDefault()}>
          {messages.map((m) => (
            <div key={m.id} className={`flex flex-col ${m.sender === 'You' ? 'items-end' : 'items-start'}`}>
              <div className={`max-w-[85%] px-6 py-4 rounded-[2.2rem] text-sm font-medium shadow-sm leading-relaxed ${
                m.sender === 'You' ? 'bg-indigo-600 text-white rounded-tr-none' : m.sender === 'System' ? 'bg-slate-100 text-slate-400 text-center w-full rounded-2xl text-[10px] italic border-none' : 'bg-white text-slate-900 rounded-tl-none border border-slate-100'
              }`}>
                {m.type === 'image' ? (
                  <div className="relative group overflow-hidden rounded-2xl">
                    <img src={m.data} className="w-full max-h-80 object-cover pointer-events-none select-none filter blur-[0.5px] hover:blur-0 transition-all" alt="View Only" />
                    <div className="absolute inset-0 bg-indigo-900/10 pointer-events-none" />
                    <div className="absolute bottom-2 right-2 px-3 py-1 bg-black/50 text-[8px] text-white rounded-full font-black uppercase">Institutional Viewing Room · Non-Downloadable</div>
                  </div>
                ) : <p>{m.text}</p>}
              </div>
              <span className="mt-1.5 px-3 text-[9px] font-black text-slate-400 uppercase tracking-widest">{m.time}</span>
            </div>
          ))}
        </div>

        {/* Input Dock - Only show if connection is active */}
        {isConnectionActive ? (
          <div className="p-8 border-t border-slate-100 bg-white shadow-[0_-10px_30px_rgba(0,0,0,0.02)]">
            <div className="flex gap-3 mb-5 overflow-x-auto hide-scrollbar pb-1">
              <button onClick={() => fileInputRef.current?.click()} className="shrink-0 px-5 py-2.5 bg-slate-50 border border-slate-100 rounded-2xl text-[10px] font-black text-slate-600 uppercase flex items-center gap-2 hover:bg-slate-100">
                <svg className="h-4 w-4 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                Share Blueprint
              </button>
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*,application/pdf" onChange={handleFileUpload} />
            </div>
            <div className="flex gap-4">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Secure signal..." 
                className="flex-1 p-5 bg-slate-50 border-2 border-transparent focus:border-indigo-600 focus:bg-white rounded-[1.8rem] outline-none font-medium text-sm transition-all shadow-inner"
              />
              <button onClick={() => sendMessage()} className="w-16 h-16 bg-slate-900 text-white rounded-[1.5rem] flex items-center justify-center shadow-xl">
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
              </button>
            </div>
          </div>
        ) : (
          <div className="p-8 border-t border-slate-100 bg-slate-100 text-center">
            <p className="text-slate-500 text-sm font-medium">Waiting for connection acceptance...</p>
            <p className="text-slate-400 text-xs mt-1">The workspace will unlock when both parties accept the connection</p>
          </div>
        )}

        {/* 4-Step Typed Confirmation Closing Modal */}
        {showClosure && (
          <div className="fixed inset-0 z-[200] bg-slate-950/95 backdrop-blur-2xl flex items-center justify-center p-4 animate-in">
            <div className="w-full max-w-xl bg-white rounded-[3.5rem] p-10 text-center shadow-2xl relative">
              <div className="absolute top-0 left-0 w-full h-2 bg-indigo-600" />
              <h2 className="text-3xl font-black text-slate-900 tracking-tighter mb-8">Exit Viewing Room</h2>

              {!terminalDecision ? (
                <div className="space-y-6">
                  <p className="text-sm font-bold text-slate-500">Do you wish to conclude this discussion? Data exchange only occurs on mutual <span className="text-indigo-600">ACCEPTANCE</span>.</p>
                  <div className="grid grid-cols-2 gap-4">
                    <button onClick={() => setTerminalDecision('ACCEPT')} className="py-6 bg-indigo-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl hover:scale-105 transition-all">Accept Deal</button>
                    <button onClick={() => setTerminalDecision('REJECT')} className="py-6 bg-slate-100 text-slate-600 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-red-50 hover:text-red-600 transition-all">Reject Deal</button>
                  </div>
                </div>
              ) : (
                <div className="space-y-8 animate-in">
                  <div className="space-y-4">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Manual Verification Step 3</p>
                    <p className="text-sm font-bold text-slate-800">You have selected <span className={terminalDecision === 'ACCEPT' ? 'text-green-600' : 'text-red-600'}>{terminalDecision}</span>.</p>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Type <span className="text-slate-900 font-black">"{terminalDecision}"</span> to confirm intent.</p>
                    <input 
                      type="text" 
                      placeholder="TYPE TO CONFIRM" 
                      className="w-full p-6 bg-slate-50 border-2 border-transparent focus:border-indigo-600 rounded-2xl text-center font-black text-xl outline-none"
                      value={typedConfirmation} 
                      onChange={(e) => setTypedConfirmation(e.target.value.toUpperCase())} 
                    />
                  </div>

                  <div className="flex flex-col gap-4">
                    <button 
                      disabled={typedConfirmation !== terminalDecision} 
                      onClick={() => onEnd(terminalDecision)}
                      className={`w-full py-6 rounded-2xl font-black text-lg transition-all shadow-xl ${typedConfirmation === terminalDecision ? (terminalDecision === 'ACCEPT' ? 'bg-indigo-600 text-white' : 'bg-red-600 text-white') : 'bg-slate-100 text-slate-300 cursor-not-allowed'}`}
                    >
                      {terminalDecision === 'ACCEPT' ? 'Finalize Handshake' : 'Execute Rejection'}
                    </button>
                    <button onClick={() => {setTerminalDecision(null); setTypedConfirmation('');}} className="py-2 text-slate-400 font-bold text-[10px] uppercase tracking-widest">Back to Decision</button>
                  </div>
                </div>
              )}
              
              <button onClick={() => setShowClosure(false)} className="mt-8 py-2 text-slate-400 font-bold text-[9px] uppercase tracking-widest border-t border-slate-50 w-full pt-4">Return to Workspace</button>
              <p className="mt-4 text-[8px] font-black text-slate-300 uppercase tracking-[0.4em]">Contact Info Exchanged Only on Mutual "ACCEPT"</p>
            </div>
          </div>
        )}

        {isAudioVaultOpen && <LiveAudioVault targetName={connection.targetName} onClose={() => setIsAudioVaultOpen(false)} />}
      </div>
    </div>
  );
};

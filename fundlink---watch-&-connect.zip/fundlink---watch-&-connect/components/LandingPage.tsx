
import React, { useState } from 'react';

interface LandingPageProps {
  onStart: () => void;
  onLogin: () => void;
}

interface TooltipProps {
  content: string;
  children: React.ReactNode;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStart, onLogin }) => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const steps = [
    {
      phase: '01',
      title: 'Identity Commit',
      tagline: 'Privacy First',
      desc: 'Select your immutable role. We enforce zero-peer visibility, ensuring founders only interact with verified institutional capital.',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
      )
    },
    {
      phase: '02',
      title: 'Vault Ingress',
      tagline: 'Trust established',
      desc: 'Authenticate via secure OTP and set up your encrypted vault. Your pitch data remains dark until you explicitly grant access.',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
        </svg>
      )
    },
    {
      phase: '03',
      title: 'Neural Audit',
      tagline: 'Verified Intelligence',
      desc: 'Our Gemini-powered Principal Layer audits your signals to generate institutional-grade readiness reports automatically.',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      )
    },
    {
      phase: '04',
      title: 'Mutual Consent',
      tagline: 'Fluid Flow',
      desc: 'Engage in the Vault Discussion. Chat, share files, and finalize terms in a secure environment built for high-stakes capital.',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      )
    }
  ];

  const Tooltip: React.FC<TooltipProps> = ({ content, children }) => {
    const [isVisible, setIsVisible] = useState(false);
    
    return (
      <div 
        className="relative inline-block"
        onMouseEnter={() => setIsVisible(true)}
        onMouseLeave={() => setIsVisible(false)}
      >
        {children}
        {isVisible && (
          <div className="absolute z-10 bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 text-xs font-bold text-white bg-slate-800 rounded-lg shadow-lg w-48 text-center">
            {content}
            <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-slate-800"></div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col min-h-screen w-full bg-slate-950 text-white relative overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4 md:px-12 flex justify-between items-center bg-slate-950/80 backdrop-blur-md border-b border-white/5">
        <div className="flex items-center space-x-2 cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
          <div className="w-9 h-9 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <span className="font-black tracking-tighter text-xl">FundLink</span>
        </div>

        <div className="hidden md:flex items-center space-x-8 text-[10px] font-black uppercase tracking-widest text-slate-500">
          <button onClick={() => scrollToSection('how-it-works')} className="hover:text-indigo-400 transition-colors">Framework</button>
          <button onClick={() => scrollToSection('security')} className="hover:text-indigo-400 transition-colors">Security</button>
          <button onClick={() => scrollToSection('network')} className="hover:text-indigo-400 transition-colors">Ecosystem</button>
        </div>

        <div className="flex items-center space-x-3">
          <button onClick={onLogin} className="text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-white transition-colors px-4">Login</button>
          <button onClick={onStart} className="px-5 py-2 bg-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-500/20">Register</button>
        </div>
      </nav>

      {/* Hero */}
      <main className="min-h-screen flex flex-col items-center justify-center px-6 pt-20 relative">
        <div className="scene mb-16 opacity-80 transform scale-90 md:scale-100">
          <div className="cube-container">
            <div className="ring"><div className="node" /></div>
            <div className="cube">
              {[...Array(6)].map((_, i) => (
                <div key={i} className={`cube-face face-${['front', 'back', 'right', 'left', 'top', 'bottom'][i]}`} />
              ))}
            </div>
            <div className="orb" />
          </div>
        </div>

        <div className="text-center max-w-4xl z-10">
          <Tooltip content="Our AI-powered system is actively analyzing market signals to connect you with the right opportunities">
            <div className="inline-block px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-[9px] font-black uppercase tracking-[0.3em] mb-8 animate-pulse cursor-help">
              Institutional Signal Engine Active
            </div>
          </Tooltip>
          <h1 className="text-5xl md:text-8xl font-black tracking-tighter mb-8 leading-[0.9] bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-500">
            Venture Capital, <br/> Encrypted.
          </h1>
          <p className="text-slate-400 text-lg md:text-xl font-medium tracking-tight leading-relaxed max-w-2xl mx-auto mb-12">
            FundLink connects high-growth Indian founders with verified global institutional capital using a strictly private, consent-driven protocol.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={onStart} className="px-12 py-5 bg-white text-slate-950 rounded-2xl font-black text-lg shadow-2xl hover:scale-105 active:scale-95 transition-all">
              Initiate Onboarding
            </button>
            <button onClick={() => scrollToSection('how-it-works')} className="px-12 py-5 bg-slate-900 text-white border border-white/5 rounded-2xl font-black text-lg hover:bg-slate-800 transition-all">
              The PTCF Framework
            </button>
          </div>
        </div>
      </main>

      {/* How it Works - PTCF Sections */}
      <section id="how-it-works" className="py-32 px-6 md:px-12 bg-slate-950 border-t border-white/5">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-6">
            <div className="max-w-xl">
              <h2 className="text-indigo-500 text-[10px] font-black uppercase tracking-[0.4em] mb-4">Mechanism</h2>
              <h3 className="text-4xl md:text-6xl font-black tracking-tighter leading-none">The FundLink Flow.</h3>
            </div>
            <p className="text-slate-500 text-sm font-medium max-w-xs md:text-right">
              Architected on the Privacy, Trust, Consent, and Flow framework for professional synergy.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {steps.map((step, i) => (
              <div key={i} className="group p-8 rounded-[2.5rem] bg-white/[0.02] border border-white/5 hover:border-indigo-500/40 hover:bg-white/[0.04] transition-all duration-500 flex flex-col h-full">
                <div className="w-14 h-14 bg-slate-900 border border-white/10 rounded-2xl flex items-center justify-center text-indigo-500 mb-8 group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-500">
                  <Tooltip content={step.desc}>
                    <div className="cursor-help">
                      {step.icon}
                    </div>
                  </Tooltip>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">{step.tagline}</span>
                    <span className="text-lg font-black text-slate-800 group-hover:text-white/20 transition-colors">{step.phase}</span>
                  </div>
                  <h4 className="text-xl font-black mb-4 tracking-tight">{step.title}</h4>
                  <p className="text-slate-400 text-xs font-medium leading-relaxed opacity-70 group-hover:opacity-100 transition-opacity">
                    {step.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Security Proof */}
      <section id="security" className="py-32 px-6 md:px-12 bg-slate-900/40">
        <div className="max-w-6xl mx-auto flex flex-col lg:flex-row gap-20 items-center">
          <div className="flex-1 order-2 lg:order-1">
            <div className="grid grid-cols-2 gap-4">
              <Tooltip content="All your data is protected with military-grade 256-bit AES encryption, the same standard used by banks and government agencies">
                <div className="aspect-square bg-white/[0.02] rounded-[3rem] border border-white/5 flex flex-col items-center justify-center p-8 text-center group hover:bg-indigo-600/10 transition-colors cursor-help">
                  <span className="text-4xl font-black mb-2 text-white">256</span>
                  <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Bit AES Vaults</span>
                </div>
              </Tooltip>
              <Tooltip content="Our zero-peer visibility protocol ensures that your information is never exposed to unauthorized parties">
                <div className="aspect-square bg-white/[0.02] rounded-[3rem] border border-white/5 flex flex-col items-center justify-center p-8 text-center mt-8 group hover:bg-indigo-600/10 transition-colors cursor-help">
                  <span className="text-4xl font-black mb-2 text-white">0%</span>
                  <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Peer Leaks</span>
                </div>
              </Tooltip>
            </div>
          </div>
          <div className="flex-1 order-1 lg:order-2">
            <h2 className="text-indigo-500 text-[10px] font-black uppercase tracking-[0.4em] mb-4">Privacy First</h2>
            <h3 className="text-4xl md:text-6xl font-black tracking-tighter mb-8 leading-tight">Dark Network <br/> Architecture.</h3>
            <p className="text-slate-400 text-lg font-medium leading-relaxed mb-10">
              Unlike social-matching platforms, FundLink operates in total darkness. You are invisible until you choose to be seen. Every connection is a mutual-consent handshake.
            </p>
            <button onClick={onStart} className="text-xs font-black uppercase tracking-[0.2em] py-4 px-8 border border-white/10 rounded-full hover:bg-white/5 transition-all">
              Review Security Protocol
            </button>
          </div>
        </div>
      </section>

      {/* Social Trust */}
      <footer id="network" className="py-20 border-t border-white/5 bg-slate-950">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <p className="text-[10px] font-black uppercase tracking-[0.5em] text-slate-600 mb-12">Trusted by verified partners</p>
          <div className="flex flex-wrap justify-center gap-12 opacity-20 hover:opacity-100 transition-opacity duration-1000">
            {['SEQUOIA', 'ACCEL', 'YC', 'LIGHTSPEED', 'BLUME'].map(p => (
              <span key={p} className="text-xl font-black tracking-tighter">{p}</span>
            ))}
          </div>
          <div className="mt-32 flex flex-col md:flex-row justify-between items-center gap-6 pt-12 border-t border-white/5">
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.3em]">© 2024 FundLink · Institutional Private Network</span>
            <div className="flex gap-8 text-[9px] font-black uppercase tracking-widest text-slate-500">
              <a href="#" className="hover:text-indigo-500">Privacy</a>
              <a href="#" className="hover:text-indigo-500">Terms</a>
              <a href="#" className="hover:text-indigo-500">Audit</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};


import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  showProgress?: boolean;
  currentStep?: number;
  totalSteps?: number;
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, 
  title, 
  subtitle,
  showProgress = false,
  currentStep = 1,
  totalSteps = 3
}) => {
  return (
    <div className="flex flex-col min-h-[600px] h-[90vh] w-full max-w-lg mx-auto bg-white rounded-3xl shadow-2xl relative overflow-hidden border border-slate-100">
      {/* Progress Header */}
      <header className="px-8 pt-10 pb-6 bg-white/80 backdrop-blur-md sticky top-0 z-20">
        {showProgress && (
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] font-bold text-slate-400 tracking-widest uppercase">
                Step {currentStep} of {totalSteps}
              </span>
              <div className="flex space-x-1">
                {Array.from({ length: totalSteps }).map((_, i) => (
                  <div 
                    key={i}
                    className={`h-1 w-10 rounded-full transition-all duration-500 ${
                      i + 1 <= currentStep ? 'bg-indigo-600 shadow-[0_0_8px_rgba(79,70,229,0.4)]' : 'bg-slate-100'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
        
        {title && (
          <h1 className="text-3xl font-bold text-slate-900 leading-tight tracking-tight">
            {title}
          </h1>
        )}
        {subtitle && (
          <p className="mt-2 text-slate-500 text-sm leading-relaxed font-medium">
            {subtitle}
          </p>
        )}
      </header>

      {/* Main Content Area */}
      <main className="flex-1 px-8 pb-10 overflow-y-auto hide-scrollbar animate-in">
        <div className="py-4">
          {children}
        </div>
      </main>
      
      {/* Safe Area for CTA */}
      <div className="h-28" />
    </div>
  );
};

import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { readFileSync, writeFileSync } from 'fs';

// Plugin to clean up HTML after build
const cleanHtmlPlugin = () => {
  return {
    name: 'clean-html',
    closeBundle() {
      const htmlPath = path.resolve(__dirname, 'dist', 'index.html');
      try {
        let html = readFileSync(htmlPath, 'utf-8');
        // Remove importmap script tag
        html = html.replace(/<script type="importmap">[\s\S]*?<\/script>/g, '');
        // Remove non-existent CSS file references
        html = html.replace(/<link[^>]*href="\/index\.css"[^>]*>/g, '');
        writeFileSync(htmlPath, html, 'utf-8');
      } catch (error) {
        console.warn('Could not clean HTML:', error);
      }
    },
  };
};

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    const isProduction = mode === 'production';
    
    return {
      base: '/',
      server: {
        port: 3000,
        host: '0.0.0.0',
      },
      build: {
        outDir: 'dist',
        sourcemap: false,
        minify: isProduction ? 'terser' : false,
        cssCodeSplit: false,
        rollupOptions: {
          output: {
            manualChunks: {
              'react-vendor': ['react', 'react-dom'],
              'ui-vendor': ['axios'],
            },
          },
        },
        cssMinify: isProduction,
      },
      plugins: [
        react({
          jsxRuntime: 'automatic',
        }),
        ...(isProduction ? [cleanHtmlPlugin()] : [])
      ],
      define: {
        'process.env.NODE_ENV': JSON.stringify(mode),
        'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY || ''),
        'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY || '')
      },
      resolve: {
        alias: {
          '@': path.resolve(__dirname, '.'),
        }
      }
    };
});
